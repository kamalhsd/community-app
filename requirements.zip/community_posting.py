import streamlit as st
import os
import pandas as pd
import requests
from datetime import datetime
import json
import sqlite3

st.set_page_config(page_title="Forum CRM Hub", layout="wide", page_icon="📡")

# ==========================================
# Google Apps Script Proxy (Firewall Bypass)
# ==========================================
# If your Nginx/Cloudflare blocks Python requests, deploy the provided Google_Apps_Script_Proxy.js
# and paste its Web App URL here. Leave empty "" to connect directly to XenForo.
GAS_PROXY_URL = "https://script.google.com/macros/s/AKfycbwIetBB304AzQePfZTcjD5QkJNjWHzlAz0-sWoDVIwIyQuqPfUm5uyuMkBy6_RVzpLu/exec"

# ==========================================
# 2. State Management (Zone 2 to Zone 3 Link)
# ==========================================

# Using st.session_state to store the active thread so UI is retained upon reruns.
if 'active_thread_id' not in st.session_state:
    st.session_state.active_thread_id = None
if 'active_site_id' not in st.session_state:
    st.session_state.active_site_id = None
if 'dashboard_data' not in st.session_state:
    st.session_state.dashboard_data = None
if 'dashboard_posts' not in st.session_state:
    st.session_state.dashboard_posts = None


# ==========================================
# XenForo Sites Configuration
# ==========================================
WEBSITES = {
    "techzeel": { "url": "https://community.techzeel.net", "key": "N1WiyPo_LLSBxwH5DjIFIG_VtLXFJ6WR" },
    "triphippies": { "url": "https://community.triphippies.com", "key": "usw7qzpu-DJSLNJRjZwtFX_UJCfptbbN" },
    "healthgroovy": { "url": "https://community.healthgroovy.com", "key": "sjdhr-_b8KcC74-rARoJ9Vf-uCO8F5Yz" },
    "learningtoday": { "url": "https://community.learningtoday.net", "key": "FSyv1CkfBqDpGd-mkI8wgCIVSYuzsubF" },
    "allinsider": { "url": "https://forum.allinsider.net", "key": "ZJoQ2YJ2HeFD4Nn2tvqJ8lLgndbHkmps" },
    "radarro": { "url": "https://community.radarro.com", "key": "xAAsWa0-Y-BEoNJASELYHYFypKtxKC9m" },
    "getassist": { "url": "https://forum.getassist.net", "key": "JfGAv9RuSVUpO7_LehiAVGRgdg19YqB1" },
    "yourhomify": { "url": "https://community.yourhomify.com", "key": "e9QvVWyGa37-0GGusiiTiuvYH3onHrW-" },
    "accountingbyte": { "url": "https://forum.accountingbyte.com", "key": "oOrx1YU-mEtvw_GEKMBdJowERzaL938H" },
    "sportsbyte": { "url": "https://community.sportsbyte.net", "key": "8OtIhtd-R1BPHi13jyXT2WsHcsayoXGZ" }
}


# Maximum pages to fetch per API endpoint to avoid excessive load times
MAX_PAGES = 5

# ==========================================
# 3. XenForo API Helper
# ==========================================

def _xf_api_get(site_id, endpoint, params=None):
    """Generic GET helper for XenForo REST API. Returns parsed JSON dict or empty dict on error."""
    site_config = WEBSITES.get(site_id.lower())
    if not site_config:
        return {}
    headers = {
        "XF-Api-Key": site_config["key"],
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }
    url = f"{site_config['url']}/api/{endpoint.lstrip('/')}"
    try:
        resp = requests.get(url, headers=headers, params=params or {}, timeout=15)
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return {}


# ==========================================
# 4. Modular Read Functions (Live XenForo API)
# ==========================================

@st.cache_data(ttl=60)
def fetch_metadata():
    """Fetch sites list, categories (nodes), and users from XenForo API for every configured site."""
    sites = list(WEBSITES.keys())
    all_cats = []
    all_users = []

    for site_id in sites:
        # --- Categories via /api/nodes ---
        nodes_data = _xf_api_get(site_id, "nodes")
        for node in nodes_data.get("nodes", []):
            if node.get("node_type_id") == "Forum":
                all_cats.append({
                    "site_id": site_id,
                    "category_name": node.get("title", ""),
                    "node_id": node.get("node_id", 0)
                })

        # --- Users via /api/users ---
        page = 1
        while True:
            users_data = _xf_api_get(site_id, "users", {"page": page})
            for u in users_data.get("users", []):
                all_users.append({
                    "site_id": site_id,
                    "username": u.get("username", ""),
                    "api_user_id": u.get("user_id", 0)
                })
            pagination = users_data.get("pagination", {})
            if page >= pagination.get("last_page", 1):
                break
            page += 1

    cats_df = pd.DataFrame(all_cats) if all_cats else pd.DataFrame(columns=["site_id", "category_name", "node_id"])
    users_df = pd.DataFrame(all_users) if all_users else pd.DataFrame(columns=["site_id", "username", "api_user_id"])
    return sites, cats_df, users_df


@st.cache_data(ttl=60)
def fetch_filtered_threads(site_id, ans_min, ans_max, selected_user, keyword, selected_categories=None):
    """
    Fetch threads from XenForo API for the given site, applying Python-side filters
    for answer count, keyword, user participation, and categories.
    Returns a DataFrame with columns: thread_id, thread_title, category, total_answers, last_active_date
    """
    # Determine which node_ids to query
    if selected_categories and len(selected_categories) > 0:
        nodes_data = _xf_api_get(site_id, "nodes")
        node_map = {}
        for n in nodes_data.get("nodes", []):
            if n.get("node_type_id") == "Forum":
                node_map[n["title"]] = n["node_id"]
        target_nodes = {name: nid for name, nid in node_map.items() if name in selected_categories}
    else:
        nodes_data = _xf_api_get(site_id, "nodes")
        target_nodes = {}
        for n in nodes_data.get("nodes", []):
            if n.get("node_type_id") == "Forum":
                target_nodes[n["title"]] = n["node_id"]

    rows = []
    for cat_name, node_id in target_nodes.items():
        page = 1
        while page <= MAX_PAGES:
            data = _xf_api_get(site_id, "threads", {"node_id": node_id, "page": page, "order": "last_post_date", "direction": "desc"})
            for t in data.get("threads", []):
                rows.append({
                    "thread_id": t.get("thread_id"),
                    "thread_title": t.get("title", ""),
                    "category": cat_name,
                    "total_answers": t.get("reply_count", 0),
                    "last_active_date": datetime.fromtimestamp(t["last_post_date"]).strftime("%Y-%m-%d %H:%M:%S") if t.get("last_post_date") else None,
                    "username": t.get("username", ""),
                    "_last_post_date_ts": t.get("last_post_date", 0),
                })
            pagination = data.get("pagination", {})
            if page >= pagination.get("last_page", 1):
                break
            page += 1

    if not rows:
        return pd.DataFrame(columns=["thread_id", "thread_title", "category", "total_answers", "last_active_date"])

    df = pd.DataFrame(rows)

    # Apply answer count filter
    df = df[(df["total_answers"] >= ans_min) & (df["total_answers"] <= ans_max)]

    # Apply keyword filter
    if keyword:
        kw_lower = keyword.lower()
        df = df[df["thread_title"].str.lower().str.contains(kw_lower, na=False)]

    # Apply user filter (thread creator matches)
    if selected_user and selected_user != "All":
        df = df[df["username"] == selected_user]

    # Sort and return only expected columns
    df = df.sort_values("_last_post_date_ts", ascending=False)
    return df[["thread_id", "thread_title", "category", "total_answers", "last_active_date"]].reset_index(drop=True)


@st.cache_data(ttl=60)
def fetch_bulk_thread_history(thread_ids, site_id):
    """Fetch chronological post history for all given thread_ids via /api/threads/{id}/posts."""
    if not thread_ids:
        return pd.DataFrame()

    all_posts = []
    site_config = WEBSITES.get(site_id.lower(), {})
    base_url = site_config.get("url", "")

    for tid in thread_ids:
        page = 1
        while page <= MAX_PAGES:
            data = _xf_api_get(site_id, f"threads/{tid}/posts", {"page": page})
            posts = data.get("posts", [])
            for idx, p in enumerate(posts):
                is_first_post = (page == 1 and idx == 0)
                post_date = datetime.fromtimestamp(p["post_date"]).strftime("%Y-%m-%d %H:%M:%S") if p.get("post_date") else None
                view_url = p.get("view_url", "")

                # Build question_url from thread view_url for the first post
                thread_view_url = ""
                if is_first_post:
                    thread_data = _xf_api_get(site_id, f"threads/{tid}")
                    thread_view_url = thread_data.get("thread", {}).get("view_url", "")

                all_posts.append({
                    "site_id": site_id,
                    "thread_id": tid,
                    "post_id": p.get("post_id", 0),
                    "username": p.get("username", p.get("User", {}).get("username", "")),
                    "content": p.get("message", ""),
                    "post_type": "Question" if is_first_post else "Answer",
                    "timestamp": post_date,
                    "target_link": "",
                    "question_url": thread_view_url if is_first_post else "",
                    "answer_url": view_url if not is_first_post else ""
                })
            pagination = data.get("pagination", {})
            if page >= pagination.get("last_page", 1):
                break
            page += 1

    if not all_posts:
        return pd.DataFrame(columns=["site_id", "thread_id", "post_id", "username", "content", "post_type", "timestamp", "target_link", "question_url", "answer_url"])

    df = pd.DataFrame(all_posts)
    df = df.sort_values("timestamp", ascending=True).reset_index(drop=True)
    return df


@st.cache_data(ttl=60)
def fetch_user_stats(site_id):
    """Aggregate threads and answers per user by scanning recent threads and their posts."""
    nodes_data = _xf_api_get(site_id, "nodes")
    node_ids = [n["node_id"] for n in nodes_data.get("nodes", []) if n.get("node_type_id") == "Forum"]

    user_threads = {}
    user_answers = {}

    for nid in node_ids:
        page = 1
        while page <= MAX_PAGES:
            data = _xf_api_get(site_id, "threads", {"node_id": nid, "page": page})
            for t in data.get("threads", []):
                creator = t.get("username", "Unknown")
                user_threads[creator] = user_threads.get(creator, 0) + 1

                # Use reply_count from thread metadata instead of fetching every post
                user_answers[t.get("last_post_username", "Unknown")] = user_answers.get(t.get("last_post_username", "Unknown"), 0) + t.get("reply_count", 0)

            pagination = data.get("pagination", {})
            if page >= pagination.get("last_page", 1):
                break
            page += 1

    all_users = set(list(user_threads.keys()) + list(user_answers.keys()))
    if not all_users:
        return pd.DataFrame(columns=["Username", "Threads_Created", "Answers_Posted"])

    rows = []
    for u in all_users:
        rows.append({
            "Username": u,
            "Threads_Created": user_threads.get(u, 0),
            "Answers_Posted": user_answers.get(u, 0)
        })
    df = pd.DataFrame(rows).sort_values(["Answers_Posted", "Threads_Created"], ascending=False).reset_index(drop=True)
    return df


@st.cache_data(ttl=60)
def fetch_daily_questions(site_id, target_date):
    """Fetch all Question threads published on a specific date from XenForo API."""
    from datetime import timedelta
    target_dt = datetime.combine(target_date, datetime.min.time())
    next_day = target_dt + timedelta(days=1)

    nodes_data = _xf_api_get(site_id, "nodes")
    node_map = {}
    for n in nodes_data.get("nodes", []):
        if n.get("node_type_id") == "Forum":
            node_map[n["node_id"]] = n.get("title", "Not Mapped")

    rows = []
    for nid, cat_name in node_map.items():
        page = 1
        while page <= MAX_PAGES:
            data = _xf_api_get(site_id, "threads", {"node_id": nid, "page": page, "order": "post_date", "direction": "desc"})
            threads = data.get("threads", [])
            stop_paging = False
            for t in threads:
                post_date_ts = t.get("post_date", 0)
                post_dt = datetime.fromtimestamp(post_date_ts)
                if post_dt < target_dt:
                    stop_paging = True
                    break
                if target_dt <= post_dt < next_day:
                    thread_url = t.get("view_url", "")
                    rows.append({
                        "Date": post_dt.strftime("%Y-%m-%d"),
                        "User": t.get("username", ""),
                        "Forum_Category": cat_name,
                        "Question": t.get("title", ""),
                        "Question_URL": thread_url
                    })
            pagination = data.get("pagination", {})
            if stop_paging or page >= pagination.get("last_page", 1):
                break
            page += 1

    if not rows:
        return pd.DataFrame(columns=["Date", "User", "Forum_Category", "Question", "Question_URL"])
    return pd.DataFrame(rows)


@st.cache_data(ttl=60)
def fetch_daily_answers(site_id, target_date):
    """Fetch all Answer replies published on a specific date from XenForo API."""
    from datetime import timedelta
    target_dt = datetime.combine(target_date, datetime.min.time())
    next_day = target_dt + timedelta(days=1)

    nodes_data = _xf_api_get(site_id, "nodes")
    node_ids = [n["node_id"] for n in nodes_data.get("nodes", []) if n.get("node_type_id") == "Forum"]

    rows = []
    for nid in node_ids:
        page = 1
        while page <= MAX_PAGES:
            data = _xf_api_get(site_id, "threads", {"node_id": nid, "page": page, "order": "last_post_date", "direction": "desc"})
            threads = data.get("threads", [])
            stop_paging = False
            for t in threads:
                last_post_ts = t.get("last_post_date", 0)
                if datetime.fromtimestamp(last_post_ts) < target_dt:
                    stop_paging = True
                    break

                tid = t["thread_id"]
                thread_url = t.get("view_url", "")
                p_page = 1
                while p_page <= MAX_PAGES:
                    posts_data = _xf_api_get(site_id, f"threads/{tid}/posts", {"page": p_page})
                    for idx, p in enumerate(posts_data.get("posts", [])):
                        if p_page == 1 and idx == 0:
                            continue  # Skip the Question post
                        pdate_ts = p.get("post_date", 0)
                        pdate_dt = datetime.fromtimestamp(pdate_ts)
                        if target_dt <= pdate_dt < next_day:
                            rows.append({
                                "Date": pdate_dt.strftime("%Y-%m-%d"),
                                "Username": p.get("username", p.get("User", {}).get("username", "")),
                                "Answer": p.get("message", ""),
                                "Question_URL": thread_url,
                                "Answer_Links": p.get("view_url", "")
                            })
                    pp = posts_data.get("pagination", {})
                    if p_page >= pp.get("last_page", 1):
                        break
                    p_page += 1

            pagination = data.get("pagination", {})
            if stop_paging or page >= pagination.get("last_page", 1):
                break
            page += 1

    if not rows:
        return pd.DataFrame(columns=["Date", "Username", "Answer", "Question_URL", "Answer_Links"])
    return pd.DataFrame(rows)


# ==========================================
# 5. AI Reply Generator (Unchanged)
# ==========================================

def generate_ai_reply(provider, api_key_or_url, model, context_df, username):
    """
    Takes the chronological thread_history_df and formats it into a robust prompt 
    for Gemini, Groq, or Ollama to generate a contextual response.
    """
    if context_df.empty:
        return "Not enough context to generate a reply."
        
    # Build conversation context string
    context_str = "Thread History:\n\n"
    for _, row in context_df.iterrows():
        context_str += f"[{row['timestamp']}] {row['username']} ({row['post_type']}):\n{row['content']}\n\n"
        
    system_prompt = f"""You are a helpful, knowledgeable participant on a specialized internet forum.
Your username is {username}. 
Review the thread history provided, and write a natural, conversational reply that directly addresses the ongoing discussion.
Do not wrap your response in quotes. Do not include signature blocks. Just write the message body."""

    try:
        if provider == "Gemini":
            if not api_key_or_url: return "Error: Gemini API Key required."
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key_or_url}"
            payload = {
                "contents": [{"parts": [{"text": f"{system_prompt}\n\n{context_str}"}]}],
                "generationConfig": {
                    "temperature": 0.7
                }
            }
            res = requests.post(url, json=payload, timeout=30)
            if res.status_code == 200:
                data = res.json()
                return data.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', 'Error: No text returned.')
            else:
                return f"Gemini API Error: {res.text}"
                
        elif provider == "Groq":
            if not api_key_or_url: return "Error: Groq API Key required."
            url = "https://api.groq.com/openai/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {api_key_or_url}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": context_str}
                ],
                "temperature": 0.7
            }
            res = requests.post(url, headers=headers, json=payload, timeout=30)
            if res.status_code == 200:
                data = res.json()
                return data.get('choices', [{}])[0].get('message', {}).get('content', 'Error: No text returned.')
            else:
                return f"Groq API Error: {res.text}"
                
        elif provider == "Ollama":
            if not api_key_or_url: return "Error: Ollama Base URL required (e.g., http://localhost:11434)."
            url = f"{api_key_or_url.rstrip('/')}/api/chat"
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": context_str}
                ],
                "stream": False
            }
            res = requests.post(url, json=payload, timeout=60)
            if res.status_code == 200:
                data = res.json()
                return data.get('message', {}).get('content', 'Error: No text returned.')
            else:
                return f"Ollama API Error: {res.text}"
                
    except Exception as e:
        return f"Request Error: {str(e)}"


# ==========================================
# 6. Write Functions (XenForo API - Unchanged)
# ==========================================

def post_to_xenforo(site_id, thread_id, api_user_id, message):
    """The REST API call using requests to XenForo."""
    site_config = WEBSITES.get(site_id.lower())
    if not site_config:
        st.error(f"Unknown site ID: {site_id}")
        return None
        
    api_key = site_config["key"]
    site_url = f"{site_config['url']}/api/posts"
    
    headers = {
        "XF-Api-Key": api_key,
        "XF-Api-User": str(api_user_id),
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    payload = {
        "thread_id": int(thread_id),
        "message": message
    }
    
    # -----------------------------------
    # Route via Google Apps Script Proxy
    # -----------------------------------
    if GAS_PROXY_URL:
        proxy_payload = {
            "target_url": site_url,
            "headers": headers,
            "payload": payload
        }
        try:
            response = requests.post(GAS_PROXY_URL, json=proxy_payload, timeout=15)
            if response.status_code == 200:
                res_json = response.json()
                if "error" in res_json:
                    st.error(f"GAS Proxy Error: {res_json['error']}")
                    return None
                    
                raw_xf_data = res_json.get("data", "{}")
                
                try:
                    xf_res = json.loads(raw_xf_data)
                    if res_json.get("status") == 200:
                        post_data = xf_res.get('post', {})
                        if 'post_id' in post_data:
                            return int(post_data['post_id']), post_data.get('view_url')
                        else:
                            st.warning(f"Reply created, but couldn't parse ID. Raw: {xf_res}")
                            return None, None
                    else:
                        st.error(f"XenForo API Error via Proxy (Code {res_json.get('status')}): {xf_res}")
                        return None, None
                except json.JSONDecodeError:
                    st.error(f"XenForo Proxy Error (HTML Returned, Code {res_json.get('status')}): {raw_xf_data[:500]}...")
                    return None, None
            else:
                st.error(f"GAS Proxy Request Failed: {response.text}")
                return None
        except Exception as e:
            st.error(f"GAS Proxy Network Error: {e}")
            return None

    # -----------------------------------
    # Direct Route
    # -----------------------------------
    try:
        response = requests.post(site_url, headers=headers, data=payload, timeout=10)
        
        if response.status_code == 200:
            post_data = response.json().get('post', {})
            return int(post_data.get('post_id')), post_data.get('view_url')
        else:
            st.error(f"XenForo API Error [{response.status_code}]: {response.text}")
            return None, None
    except requests.exceptions.ConnectionError:
        try:
            fallback_url = site_url.replace("https://", "http://")
            response = requests.post(fallback_url, headers=headers, data=payload, timeout=10)
            if response.status_code == 200:
                post_data = response.json().get('post', {})
                return int(post_data.get('post_id')), post_data.get('view_url')
            else:
                st.error(f"XenForo API Error (HTTP Fallback) [{response.status_code}]: {response.text}")
                return None, None
        except Exception as fallback_e:
            st.error(f"XenForo Network Error (HTTPS/HTTP Failed): {fallback_e}")
            return None, None
    except Exception as e:
        st.error(f"XenForo Network/Request Error: {e}")
        return None, None

def create_xenforo_thread(site_id, node_id, api_user_id, title, message):
    """The REST API call to XenForo to create a new thread."""
    site_config = WEBSITES.get(site_id.lower())
    if not site_config:
        st.error(f"Unknown site ID: {site_id}")
        return None
        
    api_key = site_config["key"]
    site_url = f"{site_config['url']}/api/threads"
        
    headers = {
        "XF-Api-Key": api_key,
        "XF-Api-User": str(api_user_id),
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    
    payload = {
        "node_id": int(node_id),
        "title": title,
        "message": message,
        "discussion_type": "discussion"
    }
    
    # -----------------------------------
    # Route via Google Apps Script Proxy
    # -----------------------------------
    if GAS_PROXY_URL:
        proxy_payload = {
            "target_url": site_url,
            "headers": headers,
            "payload": payload
        }
        try:
            response = requests.post(GAS_PROXY_URL, json=proxy_payload, timeout=15)
            if response.status_code == 200:
                res_json = response.json()
                if "error" in res_json:
                    st.error(f"GAS Proxy Error: {res_json['error']}")
                    return None
                    
                raw_xf_data = res_json.get("data", "{}")
                
                try:
                    xf_res = json.loads(raw_xf_data)
                    if res_json.get("status") == 200:
                        thread_data = xf_res.get('thread', {})
                        if 'thread_id' in thread_data:
                            return int(thread_data['thread_id']), thread_data.get('view_url')
                        else:
                            st.warning(f"Thread created, but couldn't parse ID. Raw: {xf_res}")
                            return None, None
                    else:
                        st.error(f"XenForo API Error via Proxy (Code {res_json.get('status')}): {xf_res}")
                        return None, None
                except json.JSONDecodeError:
                    st.error(f"XenForo Proxy Error (HTML Returned, Code {res_json.get('status')}): {raw_xf_data[:500]}...")
                    return None, None
            else:
                st.error(f"GAS Proxy Request Failed: {response.text}")
                return None
        except Exception as e:
            st.error(f"GAS Proxy Network Error: {e}")
            return None

    # -----------------------------------
    # Direct Route
    # -----------------------------------
    try:
        response = requests.post(site_url, headers=headers, data=payload, timeout=10)
        
        if response.status_code == 200:
            thread_data = response.json().get('thread', {})
            return int(thread_data.get('thread_id')), thread_data.get('view_url')
        else:
            st.error(f"XenForo API Error [{response.status_code}]: {response.text}")
            return None, None
    except requests.exceptions.ConnectionError:
        try:
            fallback_url = site_url.replace("https://", "http://")
            response = requests.post(fallback_url, headers=headers, data=payload, timeout=10)
            if response.status_code == 200:
                thread_data = response.json().get('thread', {})
                return int(thread_data.get('thread_id')), thread_data.get('view_url')
            else:
                st.error(f"XenForo API Error (HTTP Fallback) [{response.status_code}]: {response.text}")
                return None, None
        except Exception as fallback_e:
            st.error(f"XenForo Network Error (HTTPS/HTTP Failed): {fallback_e}")
            return None, None
    except Exception as e:
        st.error(f"XenForo Network/Request Error: {e}")
        return None, None


# ==========================================
# UI LAYOUT & ZONES
# ==========================================

st.title("📡 Forum CRM Hub")

# Fetch overall available metadata
sites, cats_df, users_df = fetch_metadata()


# ------------------------------------------
# ZONE 1: Left Sidebar (The Filter Funnel)
# ------------------------------------------
with st.sidebar:
    st.header("The Filter Funnel")
    
    selected_site = st.selectbox("Forum Selector", options=sites) if sites else None
    
    ans_min, ans_max = st.slider("Answer Count Filter", min_value=0, max_value=50, value=(0, 50))
    
    # Render categories based on site dynamically
    available_cats = cats_df[cats_df['site_id'] == selected_site]['category_name'].tolist() if not cats_df.empty and selected_site else []
    selected_categories = st.multiselect("Category Filter", options=available_cats)
    
    # Render users based on site dynamically
    available_users = ["All"] + users_df[users_df['site_id'] == selected_site]['username'].tolist() if not users_df.empty and selected_site else ["All"]
    selected_user_filter = st.selectbox("User History Search", options=available_users)
    
    keyword_filter = st.text_input("Keyword/Link Tracker")
    
    st.markdown("---")
    fetch_data_btn = st.button("🔄 Fetch Live Data", type="primary", use_container_width=True)

# State Management Check: Reset target thread if forum switches
if selected_site != st.session_state.active_site_id:
    st.session_state.active_site_id = selected_site
    st.session_state.active_thread_id = None
    st.session_state.dashboard_data = None
    st.session_state.dashboard_posts = None


# ------------------------------------------
# ZONE 2: Top Main Screen (Live Dashboard)
# ------------------------------------------
tab_main, tab_new_thread, tab_drip_scheduler, tab_user_stats, tab_daily_reports = st.tabs(["Live Dashboard", "Create New Thread", "Bulk Drip Scheduler", "User Stats", "Daily Reports"])

with tab_main:
    st.subheader("📊 Live Dashboard")
    
    if selected_site:
        if fetch_data_btn:
            with st.spinner("Fetching live data from XenForo API..."):
                st.cache_data.clear()
                df_temp = fetch_filtered_threads(
                    site_id=selected_site,
                    ans_min=ans_min,
                    ans_max=ans_max,
                    selected_user=selected_user_filter,
                    keyword=keyword_filter,
                    selected_categories=selected_categories
                )
                
                if not df_temp.empty:
                    thread_ids = df_temp['thread_id'].tolist()
                    st.session_state.dashboard_posts = fetch_bulk_thread_history(thread_ids, selected_site)
                else:
                    st.session_state.dashboard_posts = pd.DataFrame()
                    
                st.session_state.dashboard_data = df_temp
                st.session_state.active_thread_id = None
        
        df_threads = st.session_state.dashboard_data
        
        if df_threads is not None and not df_threads.empty:
            event = st.dataframe(
                df_threads, 
                use_container_width=True, 
                hide_index=True,
                selection_mode="single-row",
                on_select="rerun"
            )
            
            # Capture selection into session state
            selected_rows = event.selection.rows
            if selected_rows:
                st.session_state.active_thread_id = int(df_threads.iloc[selected_rows[0]]['thread_id'])
            else:
                st.session_state.active_thread_id = None
                
        elif df_threads is not None and df_threads.empty:
            st.info("No threads found matching the current filters.")
        else:
            st.info("👈 Click **Fetch Live Data** in the sidebar to load threads.")
    else:
        st.info("👈 Please select a forum site to display threads.")


    # ------------------------------------------
    # ZONE 3: Bottom Main Screen (Action Hub)
    # ------------------------------------------
    if st.session_state.active_thread_id:
        st.markdown("---")
        st.header(f"✍️ Action & Publishing Hub (Thread: {st.session_state.active_thread_id})")
        
        # Pull from local session cache
        all_posts_df = st.session_state.dashboard_posts
        
        if all_posts_df is not None and not all_posts_df.empty:
            thread_history_df = all_posts_df[all_posts_df['thread_id'] == st.session_state.active_thread_id]
        else:
            thread_history_df = pd.DataFrame()
        
        # Collision detection cache
        participating_users = set()
    
        if not thread_history_df.empty:
            st.subheader("Chronological History Feed")
            
            # Draw Loop natively using st.chat_message
            for _, row in thread_history_df.iterrows():
                is_question = (row['post_type'] == 'Question')
                message_type = "user" if is_question else "assistant"
                
                with st.chat_message(name=message_type):
                    st.markdown(f"**{row['username']}** | *{row['timestamp']}*")
                    st.write(row['content'])
                    
                    # Render metadata conditionally
                    if pd.notnull(row.get('target_link')) and row['target_link'] != "":
                        st.caption(f"🔗 Target Link: {row['target_link']}")
                    
                    if is_question and pd.notnull(row.get('question_url')) and row['question_url'] != "":
                        st.caption(f"🌐 Thread URL: {row['question_url']}")
                    elif not is_question and pd.notnull(row.get('answer_url')) and row['answer_url'] != "":
                        st.caption(f"🌐 Post URL: {row['answer_url']}")
                        
                # Record usernames for collision check
                participating_users.add(row['username'])
                
        # Publishing Controls
        st.subheader("Draft Reply")
        
        site_users = users_df[users_df['site_id'] == selected_site] if not users_df.empty else pd.DataFrame()
        reply_username = st.selectbox(
            "Select User to Reply As", 
            options=site_users['username'].tolist() if not site_users.empty else []
        )
        
        # Collision Detection Warning
        if reply_username in participating_users:
            st.warning("⚠️ This user has already posted in this thread.")
            
        with st.expander("🤖 AI Auto-Draft Settings", expanded=False):
            ai_provider = st.selectbox("AI Provider", ["Gemini", "Groq", "Ollama"])
            
            if ai_provider == "Ollama":
                ai_key_or_url = st.text_input("Ollama Base URL", value="http://localhost:11434")
                ai_model = st.text_input("Model Name", value="llama3.1")
            else:
                ai_key_or_url = st.text_input("API Key", type="password")
                ai_model = st.text_input("Model Name", value="gemini-2.5-flash" if ai_provider == "Gemini" else "llama3-70b-8192")

        # Session State for AI Draft Injection
        if 'draft_reply' not in st.session_state:
            st.session_state.draft_reply = ""

        reply_content = st.text_area("Message Body", value=st.session_state.draft_reply)
        target_link = st.text_input("Target SEO Link (Optional)")
        
        # Phase 2 Action button layout
        col_submit, col_ai = st.columns(2)
        
        with col_submit:
            if st.button("Publish Reply Live", type="primary"):
                if not reply_content.strip():
                    st.error("Please enter a message body before publishing.")
                elif not reply_username:
                    st.error("Please select a user to reply as.")
                else:
                    user_row = site_users[site_users['username'] == reply_username].iloc[0]
                    api_user_id = user_row['api_user_id']
                    
                    with st.spinner("Publishing via XenForo API..."):
                        new_post_id, api_answer_url = post_to_xenforo(selected_site, st.session_state.active_thread_id, api_user_id, reply_content)
                        
                        if new_post_id:
                            st.success(f"✅ Successfully published reply (Post #{new_post_id})!")
                            st.cache_data.clear()
                            st.rerun()
        
        with col_ai:
            if st.button("Auto-Draft with AI", type="secondary"):
                if not reply_username:
                    st.error("Please select a user to reply as first.")
                else:
                    with st.spinner(f"Drafting contextual reply using {ai_provider}..."):
                        generated_text = generate_ai_reply(
                            ai_provider, 
                            ai_key_or_url, 
                            ai_model, 
                            thread_history_df, 
                            reply_username
                        )
                        # Inject into Streamlit session state and force reload
                        st.session_state.draft_reply = generated_text
                        st.rerun()

with tab_new_thread:
    st.header("📝 Create New Thread")
    st.write("Publish brand new questions directly to any forum category.")
    
    if not sites:
        st.warning("No sites available in metadata.")
    else:
        new_site = st.selectbox("Select Forum Site", options=sites, key="new_thread_site")
        
        # Get users for this site
        site_users_new = users_df[users_df['site_id'] == new_site] if not users_df.empty else pd.DataFrame()
        new_username = st.selectbox(
            "Select User to Post As", 
            options=site_users_new['username'].tolist() if not site_users_new.empty else [],
            key="new_thread_user"
        )
        
        # Get categories for this site
        site_cats_new = cats_df[cats_df['site_id'] == new_site] if not cats_df.empty else pd.DataFrame()
        new_category = st.selectbox(
            "Select Category",
            options=site_cats_new['category_name'].tolist() if not site_cats_new.empty else [],
            key="new_thread_cat"
        )
        
        new_title = st.text_input("Thread Title", key="new_thread_title")
        new_content = st.text_area("Message Body", key="new_thread_content")
        new_target_link = st.text_input("Target SEO Link (Optional)", key="new_thread_target_link")
        
        if st.button("Publish New Thread", type="primary"):
            if not new_title.strip() or not new_content.strip():
                st.error("Title and Message Body are required.")
            elif not new_username or not new_category:
                st.error("User and Category must be selected.")
            else:
                user_row = site_users_new[site_users_new['username'] == new_username].iloc[0]
                api_user_id = user_row['api_user_id']
                
                cat_row = site_cats_new[site_cats_new['category_name'] == new_category].iloc[0]
                node_id = cat_row['node_id']
                
                with st.spinner(f"Publishing New Thread to {new_site}..."):
                    new_thread_id, auto_question_url = create_xenforo_thread(new_site, node_id, api_user_id, new_title, new_content)
                    
                    if new_thread_id:
                        st.success(f"✅ Successfully created thread #{new_thread_id}!")
                        st.cache_data.clear()
                        st.rerun()

with tab_drip_scheduler:
    st.header("⏳ Bulk Drip Scheduler")
    st.write("Schedule bulk questions or answers to be dripped over time. Saved locally to SQLite.")
    
    # 1. Data Entry
    schema = {
        "site_id": [""],
        "thread_id": [0],
        "username": [""],
        "content": [""],
        "post_type": ["Answer"],
        "target_link": [""]
    }
    df_in = pd.DataFrame(schema)
    
    edited_df = st.data_editor(df_in, num_rows="dynamic", use_container_width=True)
    
    st.markdown("---")
    # 2. Scheduling Controls
    col1, col2, col3 = st.columns(3)
    with col1:
        start_date = st.date_input("Start Date")
    with col2:
        start_time = st.time_input("Start Time")
    with col3:
        interval_str = st.selectbox("Interval Between Posts", ["15 Minutes", "30 Minutes", "1 Hour", "2 Hours"])
        
    # 3. Execution Logic
    if st.button("Schedule Bulk Campaign", type="primary", use_container_width=True):
        import datetime as dt_module
        
        interval_map = {
            "15 Minutes": dt_module.timedelta(minutes=15),
            "30 Minutes": dt_module.timedelta(minutes=30),
            "1 Hour": dt_module.timedelta(hours=1),
            "2 Hours": dt_module.timedelta(hours=2)
        }
        interval = interval_map[interval_str]
        
        base_time = dt_module.datetime.combine(start_date, start_time)
        
        # Filter out empty rows
        valid_df = edited_df[edited_df["content"].str.strip() != ""].copy()
        
        if valid_df.empty:
            st.error("Please enter at least one valid post.")
        else:
            with st.spinner("Calculating schedule and saving to local database..."):
                try:
                    publish_times = []
                    for idx in range(len(valid_df)):
                        pub_time = base_time + (interval * idx)
                        publish_times.append(pub_time)
                        
                    valid_df['publish_time'] = publish_times
                    valid_df['post_id'] = 0
                    
                    # Prepare final DataFrame
                    final_df = valid_df[['site_id', 'thread_id', 'post_id', 'username', 'content', 'post_type', 'target_link', 'publish_time']].copy()
                    final_df['publish_time'] = pd.to_datetime(final_df['publish_time'])
                    final_df['thread_id'] = pd.to_numeric(final_df['thread_id'], errors='coerce').fillna(0).astype(int)
                    final_df['post_id'] = final_df['post_id'].astype(int)
                    
                    # Save to local SQLite
                    db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scheduler_queue.sqlite")
                    conn = sqlite3.connect(db_path)
                    final_df.to_sql('scheduled_queue', conn, if_exists='append', index=False)
                    conn.close()
                    
                    st.success(f"✅ Successfully scheduled {len(final_df)} posts starting at {base_time.strftime('%Y-%m-%d %H:%M:%S')}! Saved to scheduler_queue.sqlite")
                except Exception as e:
                    st.error(f"Error scheduling campaign: {e}")

with tab_user_stats:
    st.header("👥 User Activity Stats")
    st.write("View the total number of Threads and Answers authored by each user.")
    
    if not sites:
        st.warning("No sites available in metadata.")
    else:
        stats_site = st.selectbox("Select Forum Site", options=sites, key="stats_site_selector")
        
        if st.button("Fetch User Stats", type="primary"):
            with st.spinner(f"Aggregating activity for {stats_site}..."):
                stats_df = fetch_user_stats(stats_site)
                
                if not stats_df.empty:
                    # Provide a metric summary above the table
                    total_threads = int(stats_df['Threads_Created'].sum())
                    total_answers = int(stats_df['Answers_Posted'].sum())
                    
                    col1, col2 = st.columns(2)
                    col1.metric("Total Threads Authored", total_threads)
                    col2.metric("Total Answers Posted", total_answers)
                    
                    st.dataframe(stats_df, use_container_width=True, hide_index=True)
                else:
                    st.info(f"No activity found for {stats_site}.")

with tab_daily_reports:
    st.header("📅 Daily Operations Report")
    st.write("Fetch all questions and answers published on a specific date.")
    
    if not sites:
        st.warning("No sites available in metadata.")
    else:
        report_site = st.selectbox("Select Forum Site", options=sites, key="report_site_selector")
        report_date = st.date_input("Select Report Date")
        
        if st.button("Generate Reports", type="primary"):
            with st.spinner(f"Fetching records for {report_site} on {report_date}..."):
                q_df = fetch_daily_questions(report_site, report_date)
                a_df = fetch_daily_answers(report_site, report_date)
                
                st.subheader(f"Questions ({len(q_df)})")
                if not q_df.empty:
                    st.dataframe(q_df, use_container_width=True, hide_index=True)
                else:
                    st.info("No questions found for this date.")
                    
                st.subheader(f"Answers ({len(a_df)})")
                if not a_df.empty:
                    st.dataframe(a_df, use_container_width=True, hide_index=True)
                else:
                    st.info("No answers found for this date.")
