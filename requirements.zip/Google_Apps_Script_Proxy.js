/**
 * Google Apps Script Web App Proxy for XenForo API
 * 
 * 1. Go to script.google.com and create a new project.
 * 2. Paste this entire file into Code.gs (replacing everything).
 * 3. Click "Deploy" -> "New deployment" at the top right.
 * 4. Select type: "Web app".
 * 5. Execute as: "Me"
 * 6. Who has access: "Anyone"
 * 7. Click Deploy, authorize the app, and copy the Web App URL.
 * 8. Paste that URL into GAS_PROXY_URL at the top of your app.py script!
 */

function doPost(e) {
  try {
    // Parse the incoming JSON payload from Streamlit app.py
    var requestData = JSON.parse(e.postData.contents);
    
    // XenForo expects data to be form-urlencoded, which UrlFetchApp 
    // does natively when 'payload' is passed as a standard JS object.
    var options = {
      method: "post",
      headers: requestData.headers || {},
      payload: requestData.payload || {},
      muteHttpExceptions: true
    };
    
    // Fire the proxied request to the actual XenForo API
    var response = UrlFetchApp.fetch(requestData.target_url, options);
    
    // Return the response back to Streamlit
    var result = {
      status: response.getResponseCode(),
      data: response.getContentText()
    };
    
    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    // Catch any networking errors and pass them back to Streamlit
    var errResult = {
      error: error.toString()
    };
    return ContentService.createTextOutput(JSON.stringify(errResult))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
